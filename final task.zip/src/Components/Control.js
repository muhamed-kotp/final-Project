import React from "react";
import Dashboard from "./Dashboard";

const Control = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default Control;
