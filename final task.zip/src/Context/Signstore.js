import { createContext } from "react";

const Signstore = createContext({
  Signstoreusername: "",
});
export default Signstore;
